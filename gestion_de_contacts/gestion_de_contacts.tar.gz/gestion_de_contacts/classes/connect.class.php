
<?php 
class Connect {
    private $host = "localhost";
    private $user = "othmane";     
    private $pass = "othmane";         
    private $db = "gestion_de_contacts";
    public $conn;
    function __construct() {
       $this->conn = new mysqli($this->host, $this->user, $this->pass, $this->db);
       if ($this->conn->connect_error) {
           die("Échec de la connexion :" . $this->conn->connect_error);
       }
       $this->conn->set_charset("utf8");
    }  
}
?>