<?php 
 require_once 'connect.class.php';
 require_once 'validator.trait.php';
 class Login{
    use Validator;
    private $email;
    private $password;
    
    function __construct($email,$password){
        if(!$this->validateEmail($email) || !$this->validatePassword($password)){
           throw new Exception("Donne de connesion incorrectes.");
        }
        $this->email=$email;
        $this->password=$password;
    }

   public function login(){
        $db=new Connect();
        $sql="SELECT * FROM users WHERE email=?";
        $stmt=$db->conn->prepare($sql);
        $stmt->bind_param('s',$this->email);
        $stmt->execute();
        $res=$stmt->get_result();
        if($res->num_rows === 1){
            $row=$res->fetch_assoc();
            $stmt->close();
            $res->free();
            if(password_verify($this->password,$row['password'])){
                $_SESSION['username']=$row['name'];
                $_SESSION['email']=$row['email'];
                $_SESSION['user_id']=$row['id'];
               return true;
            }
        }
        return false;
   }
 }

?>